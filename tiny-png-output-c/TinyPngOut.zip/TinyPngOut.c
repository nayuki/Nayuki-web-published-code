/* 
 * Tiny PNG Output (C)
 * 
 * Copyright (c) 2013 Nayuki Minase
 * http://nayuki.eigenstate.org/page/tiny-png-output-c
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program (see COPYING.txt).
 * If not, see <http://www.gnu.org/licenses/>.
 */

#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

#include "TinyPngOut.h"


/* Local declarations */

#define DEFLATE_MAX_BLOCK_SIZE 65535
#define MIN(x, y) ((x) < (y) ? (x) : (y))

static enum TinyPngOutStatus finish(struct TinyPngOut *pngout);
static uint32_t crc32  (uint32_t state, uint8_t *data, size_t len);
static uint32_t adler32(uint32_t state, uint8_t *data, size_t len);


/* Public function implementations */

enum TinyPngOutStatus TinyPngOut_init(struct TinyPngOut *pngout, FILE *fout, int32_t width, int32_t height) {
	// Check arguments
	if (fout == NULL || width <= 0 || height <= 0)
		return TINYPNGOUT_INVALID_ARGUMENT;
	
	// Calculate data size
	uint64_t lineSize = (uint64_t)width * 3 + 1;
	if (lineSize >= UINT64_C(2147483648))
		return TINYPNGOUT_IMAGE_TOO_LARGE;
	uint64_t size = lineSize * height;  // Size of DEFLATE input
	pngout->deflateRemain = (uint32_t)size;
	size += (size + DEFLATE_MAX_BLOCK_SIZE - 1) / DEFLATE_MAX_BLOCK_SIZE * 5 + 6;  // Size of zlib+DEFLATE output
	if (size >= UINT64_C(2147483648))
		return TINYPNGOUT_IMAGE_TOO_LARGE;
	
	// Set most of the fields
	pngout->width = lineSize;
	pngout->height = height;
	pngout->outStream = fout;
	pngout->positionX = 0;
	pngout->positionY = 0;
	pngout->deflateFilled = 0;
	pngout->adler = 1;
	
	// Write header
	uint8_t header[43] = {
		// PNG header
		0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
		// IHDR chunk
		0x00, 0x00, 0x00, 0x0D,
		0x49, 0x48, 0x44, 0x52,
		width  >> 24, width  >> 16, width  >> 8, width  >> 0,
		height >> 24, height >> 16, height >> 8, height >> 0,
		0x08, 0x02, 0x00, 0x00, 0x00,
		0, 0, 0, 0,  // IHDR CRC-32 to be filled in
		// IDAT chunk
		size >> 24, size >> 16, size >> 8, size >> 0,
		0x49, 0x44, 0x41, 0x54,
		// DEFLATE data
		0x08, 0x1D,
	};
	uint32_t crc = crc32(0, &header[12], 17);
	header[29] = crc >> 24;
	header[30] = crc >> 16;
	header[31] = crc >>  8;
	header[32] = crc >>  0;
	if (fwrite(header, 1, 43, fout) != 43)
		return TINYPNGOUT_IO_ERROR;
	
	pngout->crc = crc32(0, &header[37], 6);
	return TINYPNGOUT_OK;
}


enum TinyPngOutStatus TinyPngOut_write(struct TinyPngOut *pngout, uint8_t *pixels, int count) {
	int32_t width = pngout->width;
	int32_t height = pngout->height;
	if (pngout->positionY == height)
		return TINYPNGOUT_DONE;
	if (count < 0 || count > INT_MAX / 3 || pngout->positionY < 0 || pngout->positionY > height)
		return TINYPNGOUT_INVALID_ARGUMENT;
	
	count *= 3;
	FILE *f = pngout->outStream;
	while (count > 0) {
		// Start DEFLATE block
		if (pngout->deflateFilled == 0) {
			uint16_t size = (uint16_t)MIN(pngout->deflateRemain, DEFLATE_MAX_BLOCK_SIZE);
			uint8_t blockheader[5] = {
				pngout->deflateRemain <= DEFLATE_MAX_BLOCK_SIZE ? 1 : 0,
				size >> 0,
				size >> 8,
				(~size) >> 0,
				(~size) >> 8,
			};
			if (fwrite(blockheader, 1, 5, f) != 5)
				return TINYPNGOUT_IO_ERROR;
			pngout->crc = crc32(pngout->crc, blockheader, 5);
		}
		
		// Calculate number of bytes to write in this loop iteration
		int n = MIN(count, width - pngout->positionX);
		n = MIN(DEFLATE_MAX_BLOCK_SIZE - pngout->deflateFilled, n);
		if (n <= 0)  // Impossible
			exit(2);
		
		// Beginning of row - write filter method
		if (pngout->positionX == 0) {
			uint8_t b = 0;
			if (fputc(b, f) == EOF)
				return TINYPNGOUT_IO_ERROR;
			pngout->crc = crc32(pngout->crc, &b, 1);
			pngout->adler = adler32(pngout->adler, &b, 1);
			pngout->deflateRemain--;
			pngout->deflateFilled++;
			pngout->positionX++;
			n--;
		}
		
		if (fwrite(pixels, 1, n, f) != n)
			return TINYPNGOUT_IO_ERROR;
		pngout->crc = crc32(pngout->crc, pixels, n);
		pngout->adler = adler32(pngout->adler, pixels, n);
		
		// Increment the position
		count -= n;
		pixels += n;
		
		pngout->deflateRemain -= n;
		pngout->deflateFilled += n;
		if (pngout->deflateFilled == DEFLATE_MAX_BLOCK_SIZE)
			pngout->deflateFilled = 0;
		
		pngout->positionX += n;
		if (pngout->positionX == width) {
			pngout->positionX = 0;
			pngout->positionY++;
			if (pngout->positionY == height) {
				if (count > 0)
					return TINYPNGOUT_INVALID_ARGUMENT;
				return finish(pngout);
			}
		}
	}
	return TINYPNGOUT_OK;
}


/* Private function implementations */

static enum TinyPngOutStatus finish(struct TinyPngOut *pngout) {
	uint32_t adler = pngout->adler;
	uint8_t footer[20] = {
		adler >> 24, adler >> 16, adler >> 8, adler >> 0,
		0, 0, 0, 0,  // IDAT CRC-32 to be filled in
		// IEND chunk
		0x00, 0x00, 0x00, 0x00,
		0x49, 0x45, 0x4E, 0x44,
		0xAE, 0x42, 0x60, 0x82,
	};
	uint32_t crc = crc32(pngout->crc, &footer[0], 4);
	footer[4] = crc >> 24;
	footer[5] = crc >> 16;
	footer[6] = crc >>  8;
	footer[7] = crc >>  0;
	
	FILE *f = pngout->outStream;
	if (fwrite(footer, 1, 20, f) != 20)
		return TINYPNGOUT_IO_ERROR;
	
	return TINYPNGOUT_OK;
}


static uint32_t crc32(uint32_t state, uint8_t *data, size_t len) {
	state = ~state;
	size_t i;
	for (i = 0; i < len; i++) {
		unsigned int j;
		for (j = 0; j < 8; j++) {
			uint32_t bit = (state ^ (data[i] >> j)) & 1;
			state = (state >> 1) ^ ((-bit) & 0xEDB88320);
		}
	}
	return ~state;
}


static uint32_t adler32(uint32_t state, uint8_t *data, size_t len) {
	uint16_t s1 = state >>  0;
	uint16_t s2 = state >> 16;
	size_t i;
	for (i = 0; i < len; i++) {
		s1 = (s1 + data[i]) % 65521;
		s2 = (s2 + s1) % 65521;
	}
	return (uint32_t)s2 << 16 | s1;
}
