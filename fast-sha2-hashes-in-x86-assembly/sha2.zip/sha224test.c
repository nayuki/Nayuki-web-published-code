/* 
 * SHA-224 hash in C and x86 assembly
 * 
 * Copyright (c) 2014 Project Nayuki
 * All rights reserved. Contact Nayuki for licensing.
 * http://www.nayuki.io/page/fast-sha2-hashes-in-x86-assembly
 */

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


/* Function prototypes */

static int self_check(void);
void sha224_hash(const uint8_t *message, uint32_t len, uint32_t hash[7]);

// Link this program with an external C or x86 compression function
extern void sha256_compress(uint32_t state[8], const uint8_t block[64]);


/* Main program */

int main(int argc, char **argv) {
	if (!self_check()) {
		printf("Self-check failed\n");
		return 1;
	}
	printf("Self-check passed\n");
	
	// Benchmark speed
	uint32_t state[8] = {};
	uint32_t block[16] = {};
	const int N = 3000000;
	clock_t start_time = clock();
	int i;
	for (i = 0; i < N; i++)
		sha256_compress(state, (uint8_t *)block);  // Type-punning
	printf("Speed: %.1f MiB/s\n", (double)N * sizeof(block) / (clock() - start_time) * CLOCKS_PER_SEC / 1048576);
	
	return 0;
}


/* Self-check */

struct testcase {
	uint32_t answer[7];
	const uint8_t *message;
};

#define TESTCASE(a,b,c,d,e,f,g,msg) {{UINT32_C(a),UINT32_C(b),UINT32_C(c),UINT32_C(d),UINT32_C(e),UINT32_C(f),UINT32_C(g)}, (const uint8_t *)msg}

static struct testcase testCases[] = {
	TESTCASE(0xD14A028C,0x2A3A2BC9,0x476102BB,0x288234C4,0x15A2B01F,0x828EA62A,0xC5B3E42F, ""),
	TESTCASE(0x23097D22,0x3405D822,0x8642A477,0xBDA255B3,0x2AADBCE4,0xBDA0B3F7,0xE36C9DA7, "abc"),
	TESTCASE(0x75388B16,0x512776CC,0x5DBA5DA1,0xFD890150,0xB0C6455C,0xB4F58B19,0x52522525, "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"),
};

static int self_check(void) {
	unsigned int i;
	for (i = 0; i < sizeof(testCases) / sizeof(testCases[i]); i++) {
		struct testcase *tc = &testCases[i];
		uint32_t hash[7];
		sha224_hash(tc->message, strlen((const char *)tc->message), hash);
		if (memcmp(hash, tc->answer, sizeof(tc->answer)) != 0)
			return 0;
	}
	return 1;
}


/* Full message hasher */

void sha224_hash(const uint8_t *message, uint32_t len, uint32_t hash[7]) {
	uint32_t state[8] = {
		UINT32_C(0xC1059ED8),
		UINT32_C(0x367CD507),
		UINT32_C(0x3070DD17),
		UINT32_C(0xF70E5939),
		UINT32_C(0xFFC00B31),
		UINT32_C(0x68581511),
		UINT32_C(0x64F98FA7),
		UINT32_C(0xBEFA4FA4),
	};
	
	uint32_t i;
	for (i = 0; len - i >= 64; i += 64)
		sha256_compress(state, message + i);
	
	uint8_t block[64];
	uint32_t rem = len - i;
	memcpy(block, message + i, rem);
	
	block[rem] = 0x80;
	rem++;
	if (64 - rem >= 8)
		memset(block + rem, 0, 56 - rem);
	else {
		memset(block + rem, 0, 64 - rem);
		sha256_compress(state, block);
		memset(block, 0, 56);
	}
	
	uint64_t longLen = ((uint64_t)len) << 3;
	for (i = 0; i < 8; i++)
		block[64 - 1 - i] = (uint8_t)(longLen >> (i * 8));
	sha256_compress(state, block);
	
	memcpy(hash, state, 7 * sizeof(uint32_t));
}
