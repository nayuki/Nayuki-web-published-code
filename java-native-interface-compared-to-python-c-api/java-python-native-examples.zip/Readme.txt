Java & Python native library examples
=====================================


This set of programs illustrate the basic functionality of the foreign function
interface (FFI) in Java and Python. In particular, the programs compare and
contrast how analogous operations are performed using the Java Native Interface
(JNI) versus the Python/C API in CPython.

The directory structure has the program name as the first level and the
programming language as the second level. For example, "sum/java" is the "sum"
program implemented in Java. Each second-level directory contains all the source
code for that particular demo program, including the Java/Python wrapper code
and the native C code. Run the makefile with 'make run' to both build and run
that demo program. Every demo program prints some text to standard output. The
Java and Python programs for a particular demo (e.g. "map") print the same text.


Notes:

* In the Java demo makefiles, you need to modify the include paths to match your
  build environment.

* The Python demos are for Python 3 only, because the CPython API changed by a
  moderate amount from Python 2.


Copyright (c) 2016 Project Nayuki
All rights reserved. Contact Nayuki for licensing.
https://www.nayuki.io/page/java-native-interface-compared-to-python-c-api
